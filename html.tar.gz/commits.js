function make_table (object_array) {
    var table = document.createElement("table");
    var keys = Object.keys(object_array[0]);
    table.appendChild(document.createElement("tr"));
    for (var i = 0; i < keys.length; i++) {
        table.firstChild.appendChild(document.createElement("th"));
        table.firstChild.children[i].appendChild(document.createTextNode(keys[i]));
    }
    for (var i = 0, row; i < object_array.length; i++) {
        row = document.createElement("tr");
        for (var r = 0; r < keys.length; r++) {
        row.appendChild(document.createElement("td"));
            row.children[r].appendChild(document.createTextNode(object_array[i][keys[r]]));
        }
        table.appendChild(row);
    }
    return table;
}

var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function () {
    if (xhttp.readyState === 4 && xhttp.status === 200) {
        var data = JSON.parse(this.responseText).map(x => ({author: x.commit.author.name, committer: x.commit.committer.name, date: x.commit.author.date}));
        document.getElementById("content").appendChild(document.createElement("h1").appendChild(document.createTextNode("Different")));
        document.getElementById("content").appendChild(make_table(data.filter(x => x.author !== x.committer)));;
        document.getElementById("content").appendChild(document.createElement("h1").appendChild(document.createTextNode("Same")));
        document.getElementById("content").appendChild(make_table(data.filter(x => x.author === x.committer)));;
    }
}
xhttp.open("GET", "https://api.github.com/repos/bobpaw/adv-coding/commits");
xhttp.send();
