#!/usr/bin/perl

use warnings;
use strict;

my @a = {};
while (<>) {
push @a, s/\n//;
}
my $i;
foreach $i (@a) {
print $i;
}
