#!/bin/sh

# Halsey

/bin/echo -e '\e[0;34mEverything. His pills, his hands, his jeans.\e[0m\n\e[1;30mEverything. His hair, his smoke, his dreams.\e[0m'
